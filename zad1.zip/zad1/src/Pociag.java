import java.util.Random;
public class Pociag extends Thread {
    static int DWORZEC = 1;
    static int START = 2;
    static int JAZDA = 3;
    static int KONIEC_JAZDY = 4;
    static int WYPADEK = 5;
    static int TANKUJ = 1000;
    static int REZERWA = 500;
    static int MAX=100;
    //zmienne pomocnicze
    int numer;
    int paliwo;
    int ludzie;
    int wolne;
    int stan;
    Dworzec l;
    Random rand;

    public Pociag(int numer, int paliwo, int ludzie, Dworzec l) {
        this.numer = numer;
        this.paliwo = paliwo;
        this.ludzie=ludzie;
        this.stan = JAZDA;
        this.l = l;
        rand = new Random();
    }

    public void run() {
        while (true) {
            if (stan == DWORZEC) {
                if (rand.nextInt(2) == 1) {
                    stan = START;
                    paliwo = TANKUJ;
                    System.out.println("prosze o pozwolenie na wyjazd, pociągu numer " + numer);
                    stan = l.start(numer);
                } else {
                    System.out.println("Postoje sobie jeszcze troche");
                }
            } else if (stan == START) {
                System.out.println("Wyruszyłem, pociąg" + numer);
                stan = JAZDA;
            } else if (stan == JAZDA) {
                paliwo -= rand.nextInt(500);
                ludzie= rand.nextInt(100);
                wolne=MAX-ludzie;
                if (paliwo <= REZERWA) {
                    stan = KONIEC_JAZDY;
                } else try {
                    sleep(rand.nextInt(1000));
                } catch (Exception e) {
                }
            } else if (stan == KONIEC_JAZDY) {
                System.out.println("Prosze o pozowolenie na wyjazd pociągu " + numer + " ilosc paliwa " + paliwo+" liczba pasażerów: "+ludzie+" liczba wolnych miejsc "+wolne);
                stan = l.zatrzymaj();
                if (stan == KONIEC_JAZDY) {
                    paliwo -= rand.nextInt(500);
                    System.out.println("REZERWA " + paliwo);
                    if (paliwo <= 0) stan = WYPADEK;
                }
            } else if (stan == WYPADEK) {
                System.out.println("POCIĄG STOI " + numer);
                l.zmniejsz();
            }
        }
    }
}