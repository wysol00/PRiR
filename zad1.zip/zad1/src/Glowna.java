public class Glowna {
    static int ilosc_pociagow=10;
    static int ilosc_torow=5;
    static Dworzec dworzec;
    public Glowna(){
    }
    public static void main(String[] args) {
        dworzec=new Dworzec(ilosc_torow, ilosc_pociagow);
        for(int i=0;i<ilosc_pociagow;i++)
            new Pociag(i,2000,44,dworzec).start();
    }
}
