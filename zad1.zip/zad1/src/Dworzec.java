public class Dworzec {
    static int DWORZEC = 1;
    static int START = 2;
    static int JAZDA = 3;
    static int KONIEC_JAZDY = 4;
    static int WYPADEK = 5;
    int ilosc_torow;
    int ilosc_zajetych;
    int ilosc_pociagow;

    Dworzec(int ilosc_torow, int ilosc_pociagow) {
        this.ilosc_torow = ilosc_torow;
        this.ilosc_pociagow = ilosc_pociagow;
        this.ilosc_zajetych = 0;
    }

    synchronized int start(int numer) {
        ilosc_zajetych--;
        System.out.println("Pozwolenie na jazdę pociągowi " + numer);
        return START;
    }

    synchronized int zatrzymaj() {
        try {
            Thread.currentThread().sleep(1000);//sleep for 1000 ms
        } catch (Exception ie) {
        }
        if (ilosc_zajetych < ilosc_torow) {
            ilosc_zajetych++;
            System.out.println("Pozwolenie na wjazd na dworzec, ilość zajętych " + ilosc_zajetych);
            return DWORZEC;
        } else {
            return KONIEC_JAZDY;
        }
    }

    synchronized void zmniejsz() {
        ilosc_pociagow--;
        System.out.println("ZABILEM");
        if (ilosc_pociagow == ilosc_torow)
            System.out.println("ILOSC POCIĄGÓW JEST TAKA SAMA JAK ILOSC WOLNYCH TORÓW ______________");
    }
}
