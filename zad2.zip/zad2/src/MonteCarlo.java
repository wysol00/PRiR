import java.io.IOException;
import java.util.Random;
import  java.util.Scanner;
import static java.lang.Math.*;

public class MonteCarlo implements Runnable {
    int liczba;
    double valX, valY;
    double pole;
    double trafione = 0;
    Random rand = new Random();
    int bok;
    int promien;

    public MonteCarlo(int liczba,int bok,int promien) {
        this.liczba=liczba;
        this.bok=bok;
        this.promien=promien;
        this.valX = 0;
        this.valY = 0;

        this.pole = 0;


    }

    @Override
    public void run() {
        for (int i = 0; i < this.liczba; i++) {
            valX = rand.nextDouble(this.bok / 2);
            valY = rand.nextDouble(this.bok / 2);
            if (pow(valX, 2) + pow(valY, 2) <= pow(this.promien, 2)) {
                trafione = trafione + 1;
            }
        }
        pole = trafione / liczba * pow(bok, 2);
        System.out.println(pole);


    }
    public static void main(String[] args) {
        MonteCarlo m1,m2,m3,m4;

        System.out.println("Podaj liczbę losowych punktów: ");
        Scanner input = new Scanner(System.in);
        int liczba = input.nextInt();
        System.out.println("Podaj długość boku kwadratu: ");
        int bok = input.nextInt();
        System.out.println("Podaj długość promienia okręgu: ");
        int promien = input.nextInt();


        m1 = new MonteCarlo(liczba,bok,promien);
        m2 = new MonteCarlo(liczba,bok,promien);
        m3 = new MonteCarlo(liczba,bok,promien);
        m4 = new MonteCarlo(liczba,bok,promien);

        m1.run();
        m2.run();
        m3.run();
        m4.run();
    }



}